## [v1.1.0](https://github.com/conekta/conekta_prestashop/releases/tag/v1.1.0) - 2017-09-09
### Fixed
- Calculate order total in method Validate Order
- Verify payment method selected in checkout confirmation
- Logo.png not found in tpl

### Changed
- Exception control in try catch
- CDN ConektaJS
- Bundle CA Root Certificates
- Method to copy email templates

### Removed
- Unused form (payment methods)
- Unused SPEI template

## [v1.0.0](https://github.com/conekta/conekta_prestashop/releases/tag/v1.0.0) - 2017-08-17
### Update
- Online and offline payments.
- Automatic order status management.
- Sandbox testing capability.
- Client side validation for credit cards.
- All card data is sent directly to Conekta's servers so you don't have to be PCI compliant.
compatibility with prestashop 1.7